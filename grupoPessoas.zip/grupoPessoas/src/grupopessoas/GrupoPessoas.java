/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grupopessoas;

/**
 *
 * @author Jhenifer
 */
import java.util.Scanner;
public class GrupoPessoas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String sexo = null;
        double media = 0, cont, soma = 0,quant =0, conta = 0;
        int f = 0, m = 0, estatura = 0;
        
        
        Scanner inputData = new Scanner(System.in);
        System.out.println("Digite a quantidade de pessoas:");
         quant = inputData.nextDouble();
          
        for (cont = 0; cont <= quant; cont++){
            System.out.println("Digite o seu sexo:");
         sexo = inputData.next();
      
         System.out.println("Digite sua estatura:");
         estatura = (int) inputData.nextDouble();
        
         if(sexo.equals("f")) {
            f ++;
            soma += estatura;
            media = soma / f;
        }
         if (sexo.equals("m") ) {
            m ++;
    }
        System.out.println("A estatura média feminina é:"  + media + "\nO número de homens são:" + m);
}
}
}